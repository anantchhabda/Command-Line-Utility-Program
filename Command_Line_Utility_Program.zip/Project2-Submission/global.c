#include "duplicates.h"

int nfiles = 0;
size_t total_size = 0;
int unique_files = 0;
size_t min_size = 0;
